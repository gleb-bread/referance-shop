const client_manifest = {
  "VAvatar.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VAvatar.b72a6b57.css",
    "src": "VAvatar.css"
  },
  "VGrid.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VGrid.9c2ded32.css",
    "src": "VGrid.css"
  },
  "VList.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VList.f20196ef.css",
    "src": "VList.css"
  },
  "_VAvatar.2217cd27.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VAvatar.b72a6b57.css"
    ],
    "file": "VAvatar.2217cd27.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.55cece02.js"
    ]
  },
  "VAvatar.b72a6b57.css": {
    "file": "VAvatar.b72a6b57.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VContainer.af83e413.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "VContainer.af83e413.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VGrid.9c2ded32.css": {
    "file": "VGrid.9c2ded32.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VList.2842732b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VList.f20196ef.css"
    ],
    "file": "VList.2842732b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.55cece02.js",
      "_VAvatar.2217cd27.js"
    ]
  },
  "VList.f20196ef.css": {
    "file": "VList.f20196ef.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VRow.05e940c1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "VRow.05e940c1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.55cece02.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.9014554e.css"
    ],
    "file": "index.55cece02.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.9014554e.css": {
    "file": "index.9014554e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_index.649aef58.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.649aef58.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.fc701ffb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.fc701ffb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_rules.1d5d7f0f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rules.ddeeb03b.css"
    ],
    "file": "rules.1d5d7f0f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.55cece02.js",
      "_index.649aef58.js"
    ]
  },
  "rules.ddeeb03b.css": {
    "file": "rules.ddeeb03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_structHelper.28d1d036.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "structHelper.6e8d9f4b.css"
    ],
    "file": "structHelper.28d1d036.js",
    "imports": [
      "_VAvatar.2217cd27.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.55cece02.js"
    ]
  },
  "structHelper.6e8d9f4b.css": {
    "file": "structHelper.6e8d9f4b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_vue.f36acd1f.20aa3da5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.20aa3da5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.9014554e.css",
    "src": "index.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.42c71256.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.e8ae8955.js",
    "imports": [
      "_index.649aef58.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.55cece02.js",
      "_VList.2842732b.js",
      "_VAvatar.2217cd27.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.42c71256.css": {
    "file": "default.42c71256.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.5159a347.eot",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.be825c12.ttf",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.28c8f97f.woff",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.31010194.woff2",
    "src": "node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.0b8ab423.js",
    "imports": [
      "_nuxt-link.fc701ffb.js",
      "_vue.f36acd1f.20aa3da5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.2d445d75.js",
    "imports": [
      "_vue.f36acd1f.20aa3da5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.03c35c7f.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.03c35c7f.css"
    ],
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.ccdc142f.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.03c35c7f.css": {
    "file": "entry.03c35c7f.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/add_rights.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "add_rights.df04ebf8.css",
    "src": "pages/admin/add_rights.css"
  },
  "pages/admin/add_rights.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "add_rights.0305e951.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.649aef58.js",
      "_vue.f36acd1f.20aa3da5.js",
      "_VContainer.af83e413.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/add_rights.vue"
  },
  "add_rights.df04ebf8.css": {
    "file": "add_rights.df04ebf8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.f249343a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/logs.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logs.61bf0e9e.js",
    "imports": [
      "_vue.f36acd1f.20aa3da5.js",
      "_index.649aef58.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/logs.vue"
  },
  "pages/admin/rights.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "rights.fcf620c1.js",
    "imports": [
      "_vue.f36acd1f.20aa3da5.js",
      "_index.649aef58.js",
      "_VContainer.af83e413.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/rights.vue"
  },
  "pages/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "index.b0fb4619.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_structHelper.28d1d036.js",
      "_index.55cece02.js",
      "_VList.2842732b.js",
      "_VRow.05e940c1.js",
      "_index.649aef58.js",
      "_vue.f36acd1f.20aa3da5.js",
      "_VAvatar.2217cd27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/category/index.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.5f126e58.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.f7ad05cd.js",
    "imports": [
      "_index.649aef58.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_structHelper.28d1d036.js",
      "_index.55cece02.js",
      "_VRow.05e940c1.js",
      "_vue.f36acd1f.20aa3da5.js",
      "_VAvatar.2217cd27.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.5f126e58.css": {
    "file": "index.5f126e58.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/reset-password/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "index.89781b13.js",
    "imports": [
      "_nuxt-link.fc701ffb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_rules.1d5d7f0f.js",
      "_VRow.05e940c1.js",
      "_index.55cece02.js",
      "_VContainer.af83e413.js",
      "_index.649aef58.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/reset-password/index.vue"
  },
  "pages/signup/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VGrid.9c2ded32.css"
    ],
    "file": "index.8e56a030.js",
    "imports": [
      "_nuxt-link.fc701ffb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_rules.1d5d7f0f.js",
      "_VContainer.af83e413.js",
      "_VRow.05e940c1.js",
      "_index.55cece02.js",
      "_index.649aef58.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/signup/index.vue"
  },
  "rules.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "rules.ddeeb03b.css",
    "src": "rules.css"
  },
  "structHelper.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "structHelper.6e8d9f4b.css",
    "src": "structHelper.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
