const categoryItem_vue_vue_type_style_index_0_scoped_351b7c92_lang = ".filter[data-v-351b7c92]{background-color:hsla(0,0%,100%,.5)}.hovering[data-v-351b7c92]{transition-duration:.3s;transition-property:all}";

const index_vue_vue_type_style_index_0_scoped_36870dd9_lang = ".h-100-vh[data-v-36870dd9]{height:100vh}.w-100-vw[data-v-36870dd9]{width:100vw}";

const indexStyles_be1a9291 = [categoryItem_vue_vue_type_style_index_0_scoped_351b7c92_lang, index_vue_vue_type_style_index_0_scoped_36870dd9_lang, index_vue_vue_type_style_index_0_scoped_36870dd9_lang];

export { indexStyles_be1a9291 as default };
//# sourceMappingURL=index-styles.be1a9291.mjs.map
